/*
 * @author israel.arguedas
 */

package com.sc303.semana8.listasdoblescirculares;

public class Lista {
    private Nodo cabeza;
    private Nodo ultimo;
    
    public void inserta(Persona p){
        if(cabeza == null){
        cabeza = new Nodo(p);
        ultimo = cabeza;
        ultimo.setNext(cabeza);
        cabeza.setBack(ultimo);
        } else if (p.getId() < cabeza.getDato().getId()){
            Nodo aux = new Nodo(p);
            aux.setNext(cabeza);
            cabeza.setBack(aux); //Correcion
            cabeza = aux;
            ultimo.setNext(cabeza);
            cabeza.setBack(ultimo);
        } else if (ultimo.getDato().getId() <= p.getId()){
            ultimo.setNext(new Nodo(p));
            ultimo.getNext().setBack(ultimo); //Correccion
            ultimo = ultimo.getNext();
            ultimo.setNext(cabeza);
            cabeza.setBack(ultimo);
        } else {
            Nodo aux = cabeza;
            
            while(aux.getNext().getDato().getId() < p.getId()){
                Nodo temp = new Nodo(p);
                temp.setNext(aux.getNext());
                temp.setBack(aux);
                aux.setNext(temp);
                temp.getNext().setBack(temp);
            }
        }
    }
    
    //public String toString(){}
}
