/*
 * @author Laboratorios
 */

package ArchivosClasificados;

public class DatoP {
    private String numDoc;
    private int paginas;
    private boolean Clasificado;

    public DatoP() {
    }
    
    public DatoP(String numDoc, int paginas, boolean Clasificado) {
        this.numDoc = numDoc;
        this.paginas = paginas;
        this.Clasificado = Clasificado;
    }

    public String getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(String numDoc) {
        this.numDoc = numDoc;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public boolean isClasificado() {
        return Clasificado;
    }

    public void setClasificado(boolean Clasificado) {
        this.Clasificado = Clasificado;
    }

}
