/**
 * @author Laboratorios
 */

package ArchivosClasificados;

public class Main {
    public static void main(String[] args) {
        //Pruebas problema 3
        Pila p = new Pila();
        DatoP d = new DatoP("A34", 34, false);
        DatoP d2 = new DatoP("G654", 7, true);
        DatoP d3 = new DatoP("T65Y6", 76, true);
        DatoP d4 = new DatoP("HH65", 12, false);
        DatoP d5 = new DatoP("MKH81", 54, false);

        p.apilar(d);
        System.out.println("Pila actual: " + p);//mostrar pila;
        
        p.apilar(d2);
        System.out.println("Pila actual: " + p);//mostrar pila;
        
        p.apilar(d3);
        System.out.println("Pila actual: " + p);//mostrar pila;
        
        p.apilar(d4);
        System.out.println("Pila actual: " + p);//mostrar pila;
        
        p.apilar(d5);
        System.out.println("Pila actual: " + p);//mostrar pila;

    }
}
