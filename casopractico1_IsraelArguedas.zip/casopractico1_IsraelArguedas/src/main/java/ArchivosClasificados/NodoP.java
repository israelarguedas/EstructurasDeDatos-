/*
 * @author Laboratorios
 */

package ArchivosClasificados;

public class NodoP {
    private DatoP documento;
    private NodoP siguiente;

    public NodoP() {
        this.siguiente = null;
    }

    public DatoP getDocumento() {
        return documento;
    }

    public void setDocumento(DatoP documento) {
        this.documento = documento;
    }

    public NodoP getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoP siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        if (documento.isClasificado() == true){
             return "Num Documento: " + documento.getNumDoc() + ", Paginas: " + 
                documento.getPaginas() + ", Tipo de archivo: Clasificado.";
        } else {
            return "Num Documento: " + documento.getNumDoc() + ", Paginas: " + 
                documento.getPaginas() + ", Tipo de archivo: No clasificado.";
        }
    }
}