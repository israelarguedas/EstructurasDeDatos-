/*
 * @author Laboratorios
 */

package ArchivosClasificados;

import javax.swing.JOptionPane;

public class Pila {

    private NodoP cima;

    public Pila() {
        this.cima = null;
    }

    public boolean esVacia() {
        if (cima == null) {
            return true;
        } else {
            return false;
        }
    }

    public void apilar(DatoP d) {
        NodoP nuevo = new NodoP();
        nuevo.setDocumento(d);
        if (esVacia()) {
            cima = nuevo;
            System.out.println("Nuevo archivo ingresado: " + nuevo + "\n");
        } else if(cima.getDocumento().isClasificado() == false && d.isClasificado() == true){
            nuevo.setSiguiente(cima.getSiguiente());
            cima.setSiguiente(nuevo);
            System.out.println("Nuevo archivo ingresado: " + nuevo + "\n");
        }else {
            nuevo.setSiguiente(cima);
            cima = nuevo;
            System.out.println("Nuevo archivo ingresado: " + nuevo + "\n");
        }
    }

    public void desapilar() {
        if (!esVacia()) {
            cima = cima.getSiguiente();
            JOptionPane.showMessageDialog(null,
                    "Elemento extraido");
        } else {
            JOptionPane.showMessageDialog(null,
                    "No se puede extraer. Pila vacia");
        }
    }

    @Override
    public String toString() {
        String s = "";
        if (!esVacia()) {
            NodoP aux = cima;
            while (aux != null) {
                s = s + aux + "\n";
                aux = aux.getSiguiente();
            }
        }
        return s;
    }
}
