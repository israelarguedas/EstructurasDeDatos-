/*
 * @author Laboratorios
 */

package SeriedeTaylordeFunciónExponencial.SerieDeTaylor;

public class Main {
    public static void main(String[] args) {
        //Pruebas problema 1 
        SerieDeTaylor nuevaOp = new SerieDeTaylor();
        
        System.out.println("El resultado del metodo Recursivo para " + 2 + ", " + 4 + 
                " es: " + nuevaOp.calcExp(2, 4));
        System.out.println("El resultado del metodo Recursivo para " + 3 + ", " + 6 + 
                " es: " + nuevaOp.calcExp(3, 6));
        System.out.println("El resultado del metodo Recursivo para " + 4 + ", " + 8 + 
                " es: " + nuevaOp.calcExp(4, 8));
        
    }
    
}
