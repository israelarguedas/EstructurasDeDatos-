/**
 * @author Laboratorios
 */

package SeriedeTaylordeFunciónExponencial.SerieDeTaylor;

public class SerieDeTaylor {

    public SerieDeTaylor() {
    }
    
    //Wrapper
    public double calcExp(int n, int x){
        return calcExponencialR(n, x, 0);
    }
    
    //Método recursivo 
    private double calcExponencialR(int n, int x, int i){
        if (i >= n){
            return 0.0;
        }
        i++;
        return calcExponencialR(n,x,i) + (Math.pow(x,n) / fac(n) );
    }
    
    //Método iterativo 
    public double calcExponencialIt(int n, int x){
        double result = 0;
        for (int i=0;i<n;i++){
            result = result + (Math.pow(x,n) / fac(n));
        }
        return result;
    }
    
    //Método recursivo factorial
    public static int fac(int n){
        if(n==0){
            return 1;
        } else{
            return n*fac(n-1);
        }       
    }
}
