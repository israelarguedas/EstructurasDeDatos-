/**
 * @author Laboratorios
 */

package FiladelbancoFidelitas;

public class NodoC {
    private String nombre;
    private int ID;
    private int Zona;
    private NodoC atras;

    public NodoC() {
    }

    public NodoC(String nombre, int ID, int Zona) {
        this.nombre = nombre;
        this.ID = ID;
        if (Zona > 0 && Zona <= 3){
            this.Zona = Zona;
        } else {
            System.out.println("La zona ingresada no existe. Ingrese una de las siguientes opciones:"
                    + " Cajas (1) / Plataforma (2) / Servicio al cliente (3)");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getZona() {
        return Zona;
    }

    public void setZona(int Zona) {
        this.Zona = Zona;
    }

    public NodoC getAtras() {
        return atras;
    }

    public void setAtras(NodoC atras) {
        this.atras = atras;
    }

    @Override
    public String toString() {
        if (Zona == 1){
            return nombre + ", ID: " + ID + ", Zona: Cajas.";
        } else if (Zona == 2){
            return nombre + ", ID: " + ID + ", Zona: Plataforma.";
        } else if (Zona == 3){
            return nombre + ", ID: " + ID + ", Zona: Servicio al cliente.";
        }
        return "La zona ingresada no existe";
    }
}
