/**
 * @author Laboratorios
 */

package FiladelbancoFidelitas;

public class Cola {
    private NodoC frente;
    private NodoC ultimo;

    public void encola(NodoC d){
        if (frente == null){
            frente = d;
            ultimo = d;
        } else {
            ultimo.setAtras(d);
            ultimo = d;
        } 
    }
                
    public NodoC Atiende(){
        NodoC aux = frente;
        if(frente!=null){
            frente = frente.getAtras();
            aux.setAtras(null);
            
            if (aux.getZona() == 1){
                System.out.println("Cliente atendido: Nombre " + aux.getNombre() + ", Zona: Cajas" 
                        + "");
            } else if (aux.getZona() == 2){
                System.out.println("Cliente atendido: Nombre " + aux.getNombre() + ", Zona: Plataforma" 
                        + "");
            } else if (aux.getZona() == 3){
                System.out.println("Cliente atendido: Nombre " + aux.getNombre() + ", Zona: Servicio al cliente" 
                        + "");
            }
        }
        System.out.println(aux);
        return aux;
    }

    @Override
    public String toString() {
        String s = "";
        NodoC aux = frente;
        while(aux!=null){
            s += aux + "\n";
            aux = aux.getAtras();
        }
        return s;
    }
}
