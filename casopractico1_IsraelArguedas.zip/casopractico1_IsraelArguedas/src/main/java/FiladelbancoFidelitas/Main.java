/**
 * @author Laboratorios
 */

package FiladelbancoFidelitas;

public class Main {
    public static void main(String[] args) {
        Cola nuevaCola = new Cola();
        NodoC nuevoNodo = new NodoC("Alberto", 423, 1);
        NodoC nuevoNodo2 = new NodoC("Andres", 645, 2);
        NodoC nuevoNodo3 = new NodoC("Amanda", 4293, 3);
        NodoC nuevoNodo4 = new NodoC("Andrea", 252, 1);
        NodoC nuevoNodo5 = new NodoC("Alejandro", 345, 1);
        
        nuevaCola.encola(nuevoNodo);
        nuevaCola.encola(nuevoNodo2);
        nuevaCola.encola(nuevoNodo3);
        nuevaCola.encola(nuevoNodo4);
        nuevaCola.encola(nuevoNodo5);
        System.out.println("Cola actual: \n" + nuevaCola);//mostrar cola;
        
        nuevaCola.Atiende();
        nuevaCola.Atiende();
        nuevaCola.Atiende();
        
        
    }
}
